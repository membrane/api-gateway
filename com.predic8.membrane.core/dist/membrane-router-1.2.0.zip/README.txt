Membrane SOA Router 
=====================

1. Starting the Router

Execute memrouter.bat